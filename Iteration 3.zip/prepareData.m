#mean centers and scales passed observation data
#assumes passed number of observations (rows of observation matrix) 
#and passed number of features (columns of observation matrix) are correct
function X = prepareData(ctotal, nfeatures, nsamples)
  
  #Gets the mean and stdv of the new total set
  means = mean(ctotal);
  stdv = std(ctotal);
  
  #Mean-center/scale each feature, X is a NORMALIZED & MEAN CENTERED� dataset
  #data for a feature observation will be 1 if it is 1 standard deviation greater than that features mean
  for i = 1:nfeatures
    for j = 1:nsamples
      
      X(j,i) = ( means(:,i) - ctotal(j,i) ) / stdv(:,i);
      
    endfor
  endfor  
  
endfunction