clear all;
%load the csv data file
original_data = csvread('wine_beer_dataset.csv',1,1);

%means of each feature
means = mean(original_data);
%standard deviation of each feature
std_dev = std(original_data);
cov_m = cov(original_data)

[nSamples, nFeatures ] = size(original_data);
for feat = 1:nFeatures
    for obs = 1:nSamples
        X(obs,feat) = (means(:,feat) - original_data(obs,feat))/std_dev(:,feat);
    end
end

% U R is dataset

[ U S V ] = svd(X,0);
Ur = U*S;
feature_vector = 1:nFeatures;
r = Ur;
S2 = S^2;
weights2 = zeros(nFeatures,1);
sums2 = sum(sum(S2));

weight_sum2 = 0;

for i=1:nFeatures
    weights2(i) = S2(i,i)/sums2;
    weight_sum2 = weight_sum2 + weights2(i);
    weight_c2(i) = weight_sum2;
end


%plotting the scree plots
figure;
plot(weights2,'x:b');
hold on;
plot(weight_c2,'x:r');
grid;
title('Scree Plots');
    
for i=1:nFeatures
    for j=1:nFeatures
        Vsquare(i,j) = V(i,j)^2;
        if V(i,j) <0
            Vsquare(i,j) = Vsquare(i,j)*-1;
        else
            Vsquare(i,j) = Vsquare(i,j)*1
        end
    end
end

figure;
for i=1:nFeatures
%     MXN , i
%     M is number of total rows,
%     N is number of total column,
%     i is the number of plots in this graph
%     
    subplot(3,2,i);
    bar(Vsquare(:,i),0.5);
    grid;
    ymin = min(Vsquare(:,i)) + (min(Vsquare(:,i))/10);
    ymax = max(Vsquare(:,i)) + (max(Vsquare(:,i))/10);
    axis([0 nFeatures + .5 ymin ymax]);
    xlim = 4;
    xlabel('Feature Index');
    ylabel('Importance of Feature');
    [chart_title, ERRMSG] = sprintf('Loading Vector %d',i);
    title(chart_title);
end

original_data(1,:)
% setosaF = zeros(size(setosa));
% virginicaF = zeros(size(virginica));
% versicolorF = zeros(size(versicolor));
% setosaF = Ur(1:50,1:4);
% virginicaF = Ur(51:100,1:4);
% versicolorF = Ur(101:150,1:4);



    figure;
    %we want a 4X4 but this row contains 1 plot
    subplot(4,4,1);
    
    scatter(original_data(:,1),original_data(:,2),'d');
    xlabel('liquor consumption(L/yr.)(L/yr.)');
    ylabel('Wine consumption(L/yr.)');
    %liquor and wine
    %1 France
    title('liquor');
    
    %1 + 5 more empty cells to get here
    subplot(4,4,5);
    scatter(original_data(:,1),original_data(:,3),'d');
    xlabel('liquor consumption(L/yr.)');
    ylabel('Beer consumption(L/yr.)');
%
    
    %liquor and life expectacy
    subplot(4,4,9);
        scatter(original_data(:,1),original_data(:,4));
    xlabel('liquor consumption(L/yr.)');
    ylabel('life Expectancy(yr.)');

    
    subplot(4,4,13);
    scatter(original_data(:,1),original_data(:,5),'d');
    xlabel('liquor consumption(L/yr.)');
    ylabel('Heart Disease rate(yr.)');
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%% WINE
    subplot(4,4,6);
    scatter(original_data(:,2),original_data(:,3),'d');
    xlabel('Wine consumption(L/yr.)');
    ylabel('Beer consumption(L/yr.)');
    %wine and beer
    %1 France

    title('Wine')
    
    
    
    subplot(4,4,10);
    %wine and life exp
    scatter(original_data(:,2),original_data(:,4),'d');
    xlabel('Wine consumption(L/yr.)');
    ylabel('life Expectancy(yr.)');
    
   
    subplot(4,4,14);
    %wine and heart
    
    scatter(original_data(:,2),original_data(:,5),'d');
    xlabel('Wine consumption(L/yr.)');
    ylabel('Heart disease rate(yr.)');
    

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% Beer consumption(L/yr.)
    subplot(4,4,11);
    %Beer and Life Exp
    scatter(original_data(:,3),original_data(:,4),'d');
    xlabel('Beer consumption(L/yr.)');
    ylabel('Life expectancy(yr.)');
    title('Beer')

    
    subplot(4,4,15);
    %Beer and heart
    scatter(original_data(:,3),original_data(:,5),'d');
    xlabel('Beer consumption(L/yr.)');
    ylabel('Heart disease rate(yr.)');
   
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%    Life Exectancy
    subplot(4,4,16);
    
    
    %Life Exp and heart
        
    scatter(original_data(:,4),original_data(:,5),'d');
    xlabel('Life Extpectancy(yr.)');
    ylabel('Heart disease rate(yr.)');

    